package com.cognizant.carservice.exception;

import com.cognizant.carservice.dto.GenericResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<GenericResponse<?>> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(404)
                .body(new GenericResponse<>(ex.getMessage()));
    }

    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<GenericResponse<?>> handleDuplicate(DuplicateResourceException ex) {
        return ResponseEntity.status(400)
                .body(new GenericResponse<>(ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<GenericResponse<Map<String, String>>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(err ->
                errors.put(err.getField(), err.getDefaultMessage())
        );
        return ResponseEntity.status(400)
                .body(new GenericResponse<>("Validation failed", errors));
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<GenericResponse<String>> handleAccessDeniedException(AccessDeniedException ex) {
        return ResponseEntity
                .status(403)
                .body(new GenericResponse<>("Access Denied: You are not authorized to perform this action"));
    }

    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<GenericResponse<?>> handleCustomerNotFound(CustomerNotFoundException ex) {
        return ResponseEntity.status(404)
                .body(new GenericResponse<>(ex.getMessage()));
    }

    @ExceptionHandler(InvalidCarException.class)
    public ResponseEntity<GenericResponse<?>> handleInvalidCar(InvalidCarException ex) {
        return ResponseEntity.status(400)
                .body(new GenericResponse<>(ex.getMessage()));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<GenericResponse<?>> handleInvalidJson(HttpMessageNotReadableException ex) {
        return ResponseEntity.status(400)
                .body(new GenericResponse<>("Invalid input: " + ex.getMostSpecificCause().getMessage()));
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<GenericResponse<?>> handleConstraintViolation(ConstraintViolationException ex) {
        String message = ex.getConstraintViolations()
                .stream()
                .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                .collect(Collectors.joining(", "));
        return ResponseEntity.status(400)
                .body(new GenericResponse<>(message));
    }

    @ExceptionHandler(TransactionSystemException.class)
    public ResponseEntity<GenericResponse<?>> handleTransactionException(TransactionSystemException ex) {
        Throwable cause = ex.getRootCause();
        if (cause instanceof ConstraintViolationException cve) {
            String message = cve.getConstraintViolations()
                    .stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining(", "));
            return ResponseEntity.status(400)
                    .body(new GenericResponse<>(message));
        }
        return ResponseEntity.status(400)
                .body(new GenericResponse<>("Validation failed"));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<GenericResponse<?>> handleGeneric(Exception ex) {
        return ResponseEntity.status(500)
                .body(new GenericResponse<>(ex.getMessage()));
    }
}