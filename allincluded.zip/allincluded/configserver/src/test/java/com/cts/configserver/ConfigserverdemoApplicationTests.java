package com.cts.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserverdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
