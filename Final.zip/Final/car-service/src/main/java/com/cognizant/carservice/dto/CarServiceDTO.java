package com.cognizant.carservice.dto;

import com.cognizant.carservice.enums.ServiceStatus;
import com.cognizant.carservice.enums.ServiceType;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CarServiceDTO {

    @Schema(hidden = true)
    private Long id;

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotBlank(message = "Car registration number is required")
    private String carRegistrationNumber;

    @NotNull(message = "Service type is required")
    private ServiceType serviceType;

    @NotNull(message = "Service status is required")
    private ServiceStatus serviceStatus;

    @NotNull(message = "Service date is required")
    private LocalDate serviceDate;

    @Size(max = 250, message = "Notes must not exceed 250 characters")
    private String notes;

    @Schema(hidden = true)
    private LocalDateTime createdAt;

    @Schema(hidden = true)
    private LocalDateTime updatedAt;
}
