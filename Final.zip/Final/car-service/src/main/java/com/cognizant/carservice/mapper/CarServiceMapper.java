package com.cognizant.carservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.cognizant.carservice.dto.CarServiceDTO;
import com.cognizant.carservice.dto.CarServiceResponse;
import com.cognizant.carservice.model.CarService;

@Mapper(componentModel = "spring")
public interface CarServiceMapper {

    // DTO → Entity
    CarService dtoToEntity(CarServiceDTO dto);

    // Entity → Response record
    CarServiceResponse entityToResponse(CarService entity);

    // List mapping
    List<CarServiceResponse> entityListToResponseList(List<CarService> list);
}